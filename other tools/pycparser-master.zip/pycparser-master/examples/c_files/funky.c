char foo(void)
{
    return '1';
}

int maxout_in(int paste, char** matrix)
{
    char o = foo();
    return (int) matrix[1][2] * 5 - paste;
}

int main()
{
    auto char* multi = "a multi";
    
    
}



