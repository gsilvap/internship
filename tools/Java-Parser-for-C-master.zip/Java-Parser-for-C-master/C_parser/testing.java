class testing
{
  public static void main(String a[])
   {
  String str = " < ";
str = str.toLowerCase();
  if(str.equals("<")) System.out.println("matches");
}
}