package Handler;
import java.util.ArrayList;

public class ParentFunction {
  public ArrayList<String> innerFunctions = new ArrayList<String>();
  
  public String functionName;
  
  public ParentFunction(String str)
  {
	  functionName=str;	  
  }
}
