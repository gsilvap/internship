package Handler;

public class GraphNode {
	
	 public String nodeName;
		 
	 public GraphNode parentNode;
	 
	 public GraphNode(String str)
	 {
		 nodeName =str;
	 }
}
